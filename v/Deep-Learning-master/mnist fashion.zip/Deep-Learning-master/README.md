# Deep-Learning

Un simulateur pour les réseaux de neurones
[Simulateur](https://playground.tensorflow.org/#activation=tanh&batchSize=10&dataset=circle&regDataset=reg-plane&learningRate=0.03&regularizationRate=0&noise=0&networkShape=4,2&seed=0.54123&showTestData=false&discretize=false&percTrainData=50&x=true&y=true&xTimesY=false&xSquared=false&ySquared=false&cosX=false&sinX=false&cosY=false&sinY=false&collectStats=false&problem=classification&initZero=false&hideText=false)

Des tutos pour tensorflow : 
[Site](https://www.tensorflow.org/tutorials)


Un livre
[Aurélien geron : Deep learning avec Tensorflow](https://www.amazon.fr/Deep-Learning-avec-TensorFlow-concrets/dp/2100759930)

